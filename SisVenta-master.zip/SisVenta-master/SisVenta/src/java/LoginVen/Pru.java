
package LoginVen;

public class Pru {
  
    public static void main(String[] args) {
        MySQLConexion.getConexion();
    }
}
